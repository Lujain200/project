
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/AddToCartServlet")
public class AddToCartServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int productId = Integer.parseInt(request.getParameter("productId"));
        int quantity = Integer.parseInt(request.getParameter("quantity"));

        // Get product details from database
        String jdbcURL = "jdbc:derby://localhost:1527/L1";
        String dbUser = "lujain";
        String dbPassword = "12345";

        try (Connection connection = DriverManager.getConnection(jdbcURL, dbUser, dbPassword)) {
            String sql = "SELECT * FROM products WHERE id = ?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setInt(1, productId);
                ResultSet resultSet = statement.executeQuery();

                if (resultSet.next()) {
                    String name = resultSet.getString("name");
                    double price = resultSet.getDouble("price");

                    // Create product object and add to cart
                    Product product = new Product(productId, name, resultSet.getString("brand"), resultSet.getString("category"), price, quantity);

                    HttpSession session = request.getSession();
                    List<Product> cart = (List<Product>) session.getAttribute("cart");

                    if (cart == null) {
                        cart = new ArrayList<>();
                        session.setAttribute("cart", cart);
                    }

                    // Check if product already exists in the cart
                    boolean found = false;
                    for (Product p : cart) {
                        if (p.getId() == productId) {
                            p.setQuantity(p.getQuantity() + quantity); // Update quantity
                            found = true;
                            break;
                        }
                    }

                    if (!found) {
                        cart.add(product); // Add new product to cart
                    }

                    response.sendRedirect("viewCart.jsp");
                } else {
                    request.setAttribute("errorMessage", "Product not found.");
                    request.getRequestDispatcher("/error.jsp").forward(request, response);
                }
            }
        } catch (Exception e) {
            request.setAttribute("errorMessage", "Database error: " + e.getMessage());
            request.getRequestDispatcher("/error.jsp").forward(request, response);
        }
    }

    private static class Product {

        public Product(int productId, String name, String string, String string1, double price, int quantity) {
        }

        private int getId() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        private int getQuantity() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        private void setQuantity(int i) {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }
    }
}
