package com.example.admin;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/AdminLoginServlet")
public class AdminLoginServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve form parameters
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        // Database connection settings
        String jdbcURL = "jdbc:derby://localhost:1527/L1";
        String dbUser = "lujain";
        String dbPassword = "12345";

        try (Connection connection = DriverManager.getConnection(jdbcURL, dbUser, dbPassword)) {
            // Correct SQL query with placeholders
            String sql = "SELECT admin_id FROM admins WHERE username = ? AND password = ?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                // Set parameters for the prepared statement
                statement.setString(1, username);
                statement.setString(2, password);

                ResultSet resultSet = statement.executeQuery();

                if (resultSet.next()) {
                    // Successful login, retrieve admin ID
                    int adminId = resultSet.getInt("admin_id");

                    // Create session and set attributes
                    HttpSession session = request.getSession();
                    session.setAttribute("adminUsername", username);
                    session.setAttribute("adminId", adminId);

                    // Redirect to success page
                    response.sendRedirect("admin_success.jsp");
                } else {
                    // Invalid credentials, redirect to failure page
                    request.setAttribute("errorMessage", "Invalid username or password.");
                    request.getRequestDispatcher("admin_fail.jsp").forward(request, response);
                }
            }
        } catch (Exception e) {
            // Handle database errors
            request.setAttribute("errorMessage", "Database error: " + e.getMessage());
            request.getRequestDispatcher("admin_fail.jsp").forward(request, response);
        }
    }
}
