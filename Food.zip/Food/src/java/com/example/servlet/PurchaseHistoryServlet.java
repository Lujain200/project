package com.example.servlet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.logging.Level;
import java.util.logging.Logger;

@WebServlet("/PurchaseHistoryServlet")
public class PurchaseHistoryServlet extends HttpServlet {

    private static final Logger LOGGER = Logger.getLogger(PurchaseHistoryServlet.class.getName());

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

        // Assume customer_id is stored in the session after login
        HttpSession session = request.getSession();
        Integer customerId = (Integer) session.getAttribute("customerId");

        if (customerId == null) {
            response.sendRedirect("signin.jsp");
            return;
        }

        try (PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Purchase History</title>");
            out.println("<style>");
            out.println("body { font-family: Arial, sans-serif; margin: 20px; }");
            out.println("table { width: 100%; border-collapse: collapse; }");
            out.println("table, th, td { border: 1px solid #ddd; }");
            out.println("th, td { padding: 10px; text-align: left; }");
            out.println("th { background-color: #4CAF50; color: white; }");
            out.println("</style>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Purchase History</h1>");

            try (Connection conn = DriverManager.getConnection("jdbc:derby://localhost:1527/L", "lujain", "12345")) {
                String query = "SELECT p.purchase_id, i.name, i.brand, p.quantity, p.total_price, p.purchase_date " +
                               "FROM Purchases p " +
                               "JOIN Items i ON p.item_id = i.tid " +
                               "WHERE p.customer_id = ?";
                try (PreparedStatement pstmt = conn.prepareStatement(query)) {
                    pstmt.setInt(1, customerId);

                    try (ResultSet rs = pstmt.executeQuery()) {
                        out.println("<table>");
                        out.println("<tr>");
                        out.println("<th>Purchase ID</th>");
                        out.println("<th>Item Name</th>");
                        out.println("<th>Brand</th>");
                        out.println("<th>Quantity</th>");
                        out.println("<th>Total Price</th>");
                        out.println("<th>Purchase Date</th>");
                        out.println("</tr>");

                        boolean hasResults = false;
                        while (rs.next()) {
                            hasResults = true;
                            out.println("<tr>");
                            out.println("<td>" + rs.getInt("purchase_id") + "</td>");
                            out.println("<td>" + rs.getString("name") + "</td>");
                            out.println("<td>" + rs.getString("brand") + "</td>");
                            out.println("<td>" + rs.getInt("quantity") + "</td>");
                            out.println("<td>$" + rs.getDouble("total_price") + "</td>");
                            out.println("<td>" + rs.getTimestamp("purchase_date") + "</td>");
                            out.println("</tr>");
                        }

                        if (!hasResults) {
                            out.println("<tr><td colspan='6'>No purchase history found.</td></tr>");
                        }

                        out.println("</table>");
                    }
                }
            } catch (Exception e) {
                // Log the error
                LOGGER.log(Level.SEVERE, "Database error", e);
                out.println("<p>An error occurred while retrieving purchase history. Please try again later.</p>");
            }

            out.println("</body>");
            out.println("</html>");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
}
