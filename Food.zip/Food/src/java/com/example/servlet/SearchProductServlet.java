package com.example.servlet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/SearchProductServlet")
public class SearchProductServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String searchQuery = request.getParameter("searchQuery");
        String category = request.getParameter("category");

        // Database connection settings
        String jdbcURL = "jdbc:derby://localhost:1527/L1";
        String dbUser = "lujain";
        String dbPassword = "12345";

        try (Connection connection = DriverManager.getConnection(jdbcURL, dbUser, dbPassword)) {
            String query;
            PreparedStatement statement;

            if (category == null || category.isEmpty()) {
                query = "SELECT * FROM products WHERE name LIKE ? OR brand LIKE ?";
                statement = connection.prepareStatement(query);
                statement.setString(1, "%" + searchQuery + "%");
                statement.setString(2, "%" + searchQuery + "%");
            } else {
                query = "SELECT * FROM products WHERE (name LIKE ? OR brand LIKE ?) AND category = ?";
                statement = connection.prepareStatement(query);
                statement.setString(1, "%" + searchQuery + "%");
                statement.setString(2, "%" + searchQuery + "%");
                statement.setString(3, category);
            }

            ResultSet resultSet = statement.executeQuery();
            List<Product> productList = new ArrayList<>();

            while (resultSet.next()) {
                Product product = new Product(
                        resultSet.getInt("id"),
                        resultSet.getString("name"),
                        resultSet.getString("brand"),
                        resultSet.getString("category"),
                        resultSet.getDouble("price"),
                        resultSet.getInt("stock")
                );
                productList.add(product);
            }

            request.setAttribute("products", productList);
            request.getRequestDispatcher("searchResults.jsp").forward(request, response);

        } catch (Exception e) {
            request.setAttribute("errorMessage", "Database error: " + e.getMessage());
            request.getRequestDispatcher("/error.jsp").forward(request, response);
        }
    }
}
