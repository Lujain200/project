package com.example.servlet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

@WebServlet("/UpdateProfileServlet")
public class UpdateProfileServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();
        Integer customerId = (Integer) session.getAttribute("customerId");
        String name = request.getParameter("name");
        String phoneNumber = request.getParameter("phoneNumber");

        try (Connection conn = DriverManager.getConnection("jdbc:derby://localhost:1527/L", "lujain", "12345")) {
            String sql = "UPDATE customers SET name = ?, phone_number = ? WHERE customer_id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, name);
                pstmt.setString(2, phoneNumber);
                pstmt.setInt(3, customerId);
                pstmt.executeUpdate();

                // Update session attributes
                session.setAttribute("name", name);
                session.setAttribute("phoneNumber", phoneNumber);

                response.sendRedirect("welcome.jsp");
            }
        } catch (Exception e) {
            response.sendRedirect("error.jsp");
        }
    }
}
