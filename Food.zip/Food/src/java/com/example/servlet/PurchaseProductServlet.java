package com.example.servlet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

@WebServlet("/PurchaseProductServlet")
public class PurchaseProductServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        Integer customerId = (Integer) session.getAttribute("customerId");
        int productId = Integer.parseInt(request.getParameter("productId"));
        int quantity = Integer.parseInt(request.getParameter("quantity"));

        try (Connection conn = DriverManager.getConnection("jdbc:derby://localhost:1527/L", "lujain", "12345")) {
            // Fetch product details
            String productQuery = "SELECT price FROM items WHERE tid = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(productQuery)) {
                pstmt.setInt(1, productId);
                try (ResultSet rs = pstmt.executeQuery()) {
                    if (rs.next()) {
                        double price = rs.getDouble("price");
                        double totalPrice = price * quantity;

                        // Check if user has enough balance
                        double balance = (Double) session.getAttribute("balance");
                        if (balance >= totalPrice) {
                            // Proceed with the purchase
                            String purchaseQuery = "INSERT INTO Purchases (customer_id, item_id, quantity, total_price) VALUES (?, ?, ?, ?)";
                            try (PreparedStatement purchaseStmt = conn.prepareStatement(purchaseQuery)) {
                                purchaseStmt.setInt(1, customerId);
                                purchaseStmt.setInt(2, productId);
                                purchaseStmt.setInt(3, quantity);
                                purchaseStmt.setDouble(4, totalPrice);
                                purchaseStmt.executeUpdate();

                                // Update user balance
                                String updateBalanceQuery = "UPDATE customers SET balance = balance - ? WHERE customer_id = ?";
                                try (PreparedStatement updateBalanceStmt = conn.prepareStatement(updateBalanceQuery)) {
                                    updateBalanceStmt.setDouble(1, totalPrice);
                                    updateBalanceStmt.setInt(2, customerId);
                                    updateBalanceStmt.executeUpdate();
                                }

                                // Update session with new balance
                                session.setAttribute("balance", balance - totalPrice);
                                response.sendRedirect("welcome.jsp");
                            }
                        } else {
                            request.setAttribute("errorMessage", "Insufficient balance.");
                            request.getRequestDispatcher("searchProducts.jsp").forward(request, response);
                        }
                    }
                }
            }
        } catch (Exception e) {
            response.sendRedirect("error.jsp");
        }
    }
}
