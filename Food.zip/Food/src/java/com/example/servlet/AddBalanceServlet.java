package com.example.servlet;


import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/AddBalanceServlet")
public class AddBalanceServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get the amount to add from the form
        double amountToAdd = Double.parseDouble(request.getParameter("amount"));

        // Get customer details from session
        HttpSession session = request.getSession();
        String customerId = (String) session.getAttribute("customerId");

        // Database connection settings
        String jdbcURL = "jdbc:derby://localhost:1527/L1";
        String dbUser = "lujain";
        String dbPassword = "12345";

        try (Connection connection = DriverManager.getConnection(jdbcURL, dbUser, dbPassword)) {
            // Query to get the current balance and add the amount
            String sql = "UPDATE customers SET balance = balance + ? WHERE customer_id = ?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setDouble(1, amountToAdd);
                statement.setString(2, customerId);
                
                int rowsUpdated = statement.executeUpdate();

                if (rowsUpdated > 0) {
                    // Update the balance in session
                    double newBalance = getUpdatedBalance(connection, customerId);
                    session.setAttribute("balance", newBalance);

                    // Redirect back to the user dashboard with a success message
                    response.sendRedirect("user-dashboard.jsp");
                } else {
                    request.setAttribute("errorMessage", "Failed to add balance.");
                    request.getRequestDispatcher("/user-dashboard.jsp").forward(request, response);
                }
            } catch (Exception e) {
                request.setAttribute("errorMessage", "Error updating balance: " + e.getMessage());
                request.getRequestDispatcher("/user-dashboard.jsp").forward(request, response);
            }
        } catch (Exception e) {
            request.setAttribute("errorMessage", "Database connection error: " + e.getMessage());
            request.getRequestDispatcher("/user-dashboard.jsp").forward(request, response);
        }
    }

    private double getUpdatedBalance(Connection connection, String customerId) throws SQLException {
        String sql = "SELECT balance FROM customers WHERE customer_id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, customerId);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                return resultSet.getDouble("balance");
            }
        }
        return 0.0;
    }
}
