package com.example.SignInServlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/SignInServlet")
public class SignInServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve form parameters
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        // Database connection settings
        String jdbcURL = "jdbc:derby://localhost:1527/L1";
        String dbUser = "lujain";
        String dbPassword = "12345";

        try (Connection connection = DriverManager.getConnection(jdbcURL, dbUser, dbPassword)) {
            // Query to check if the customer exists with the given email
            String sql = "SELECT customer_id, name, phone_number, balance, password FROM customers WHERE email = ?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, email);
                ResultSet resultSet = statement.executeQuery();

                if (resultSet.next()) {
                    // Retrieve customer details from the result set
                    String storedPassword = resultSet.getString("password"); // Password should be hashed
                    if (storedPassword.equals(password)) { // Simple plain-text comparison (replace with hashed comparison in production)
                        String customerId = resultSet.getString("customer_id");
                        String name = resultSet.getString("name");
                        String phoneNumber = resultSet.getString("phone_number");
                        double balance = resultSet.getDouble("balance");

                        // Create session for the authenticated customer
                        HttpSession session = request.getSession();
                        session.setAttribute("customerId", customerId);
                        session.setAttribute("name", name);
                        session.setAttribute("email", email);
                        session.setAttribute("phoneNumber", phoneNumber);
                        session.setAttribute("balance", balance);

                        // Redirect to user dashboard
                        response.sendRedirect("user-dashboard.jsp");
                    } else {
                        // Show error message if password is incorrect
                        request.setAttribute("errorMessage", "Invalid password.");
                        request.getRequestDispatcher("/signin.jsp").forward(request, response);
                    }
                } else {
                    // Show error message if email is not found
                    request.setAttribute("errorMessage", "Invalid email.");
                    request.getRequestDispatcher("/signin.jsp").forward(request, response);
                }
            } catch (Exception e) {
                // Handle any exceptions that may occur during database interaction
                request.setAttribute("errorMessage", "Database error: " + e.getMessage());
                request.getRequestDispatcher("/signin.jsp").forward(request, response);
            }
        } catch (Exception e) {
            // Handle database connection errors
            request.setAttribute("errorMessage", "Database connection error: " + e.getMessage());
            request.getRequestDispatcher("/signin.jsp").forward(request, response);
        }
    }
}
