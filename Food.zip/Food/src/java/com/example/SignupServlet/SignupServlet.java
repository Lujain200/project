package com.example.SignupServlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/SignupServlet")
public class SignupServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve form parameters
        String customer_id = request.getParameter("customer_id");
        String name = request.getParameter("name");
        String ageStr = request.getParameter("age");
        String phoneNumber = request.getParameter("phone_number");
        String address = request.getParameter("address");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String balanceStr = request.getParameter("balance");

        // Parse numeric values
        int age = Integer.parseInt(ageStr);
        double balance = Double.parseDouble(balanceStr);
        Timestamp createdAt = new Timestamp(System.currentTimeMillis());

        // Validate password
        String passwordErrorMessage = validatePassword(password);
        if (passwordErrorMessage != null) {
            request.setAttribute("errorMessage", passwordErrorMessage);
            request.getRequestDispatcher("/sigup.jsp").forward(request, response);
            return;
        }

        // Database connection settings
        String jdbcURL = "jdbc:derby://localhost:1527/L1";
        String dbUser = "lujain";
        String dbPassword = "12345";

        try (Connection connection = DriverManager.getConnection(jdbcURL, dbUser, dbPassword)) {
            // Check if email already exists
            String checkEmailSql = "SELECT * FROM customers WHERE email = ?";
            try (PreparedStatement checkEmailStmt = connection.prepareStatement(checkEmailSql)) {
                checkEmailStmt.setString(1, email);
                ResultSet emailResultSet = checkEmailStmt.executeQuery();

                if (emailResultSet.next()) {
                    request.setAttribute("errorMessage", "Email already exists. Please choose a different email.");
                    request.getRequestDispatcher("/sigup.jsp").forward(request, response);
                } else {
                    // Insert new customer with additional fields
                    String sql = "INSERT INTO customers (customer_id, name, age, phone_number, address, email, password, balance, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
                    try (PreparedStatement statement = connection.prepareStatement(sql)) {
                        statement.setString(1, customer_id); // Corrected to use customerId
                        statement.setString(2, name);
                        statement.setInt(3, age);
                        statement.setString(4, phoneNumber);
                        statement.setString(5, address);
                        statement.setString(6, email);
                        statement.setString(7, password); // Store password as plain text (not recommended for production)
                        statement.setDouble(8, balance);
                        statement.setTimestamp(9, createdAt);

                        int rowsInserted = statement.executeUpdate();

                        if (rowsInserted > 0) {
                            response.sendRedirect("success.jsp");
                        } else {
                            request.setAttribute("errorMessage", "Error: Could not complete signup. Please try again later.");
                            request.getRequestDispatcher("/sigup.jsp").forward(request, response);
                        }
                    }
                }
            }
        } catch (Exception e) {
            request.setAttribute("errorMessage", "Database error: " + e.getMessage());
            request.getRequestDispatcher("/sigup.jsp").forward(request, response);
        }
    }

    // Password validation method
    public String validatePassword(String password) {
        if (password.length() < 8) return "Password must be at least 8 characters long.";
        if (!password.matches(".*[A-Z].*")) return "Password must contain at least one uppercase letter.";
        if (!password.matches(".*[a-z].*")) return "Password must contain at least one lowercase letter.";
        if (!password.matches(".*[0-9].*")) return "Password must contain at least one number.";
        if (!password.matches(".*[!@#$%^&*(),.?\":{}|<>].*")) return "Password must contain at least one special character.";
        return null; // Valid password
    }
}
