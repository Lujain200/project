import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/CheckoutServlet")
public class CheckoutServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        
        // Retrieve the cart from session (it should be a List of Product objects)
        List<Product> cart = (List<Product>) session.getAttribute("cart");
        
        // Initialize total amount
        double totalAmount = 0;

        // Check if the cart is not null
        if (cart != null) {
            // Loop through each product in the cart and calculate the total amount
            for (Product product : cart) {
                totalAmount += product.getPrice() * product.getQuantity();
            }
        }

        // Set the total amount as an attribute to display it in the JSP
        request.setAttribute("totalAmount", totalAmount);

        // Forward the request to checkout.jsp for displaying the cart and total
        request.getRequestDispatcher("checkout.jsp").forward(request, response);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    // A simple Product class for illustration purposes
    public static class Product {
        private String name;
        private double price;
        private int quantity;

        public Product(String name, double price, int quantity) {
            this.name = name;
            this.price = price;
            this.quantity = quantity;
        }

        public String getName() {
            return name;
        }

        public double getPrice() {
            return price;
        }

        public int getQuantity() {
            return quantity;
        }
    }
}
